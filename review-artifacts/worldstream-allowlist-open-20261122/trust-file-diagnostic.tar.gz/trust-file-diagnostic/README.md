# Trust-file open diagnostic

The non-root verifier treated an existing, unreadable allowlist as an untrusted signer. With the correction a required lookup that cannot open the existing file returns `RECEIPT_VERIFIER_UNAVAILABLE` and the existing evidence token `signer_key_unreadable`. The receipt remains unverified.

| Identity | Commit |
|---|---|
| Qualified candidate | `a2302436f42f2e68810efc125c4b35cf1c4dd211` |
| Qualified parent | `82df97517f00e260710415117a2163c58ef289ca` |
| Upstream main at start | `2a93470e27c2197ff13813e3a6f6f46893c5a538` |
| Prerequisite | `381d58c1b0e1c0b15a19aa1d0c0612d03a61d457` |

The parent replays the pending prerequisite on the observed main. The original and replay have identical stable patch IDs. The signer and receipt-verifier source blobs on the parent match the original prerequisite. The new patch replays to the qualified tree on that parent and applies cleanly to the original prerequisite. This local package records the follow-on independently of the existing native relay.

## Reproduction

The admitted worker ran as UID 1001 with the read-only fixture sandbox, case-local state and networking disabled. Each phase used the same synthetic signed receipt, offer and established public signer. No private key was in the fixture. The controller changed only the disposable allowlist between calls. The worker explicitly opened the file under the same profile and credential set as the native CLI. All parent directories remained traversable. Before and after each native invocation the controller compared content, directory entries, modes, ownership and modification times.

| Allowlist | Worker open | Before | After |
|---|---|---|---|
| Readable | Success | Verified, exit 0 | Verified, exit 0 |
| Existing, mode 000 | EACCES | Unknown signer, exit 1 | Verifier unavailable, exit 1 |
| Absent | ENOENT | Unknown signer, exit 1 | Unknown signer, exit 1 |
| Restored | Success | Verified, exit 0 | Verified, exit 0 |

All refusals emitted `mutated=false`. All eight case snapshots matched across their invocation. The JSON records contain the exact evidence on every refusal. A separate control confirmed the retained size policy in both binaries, including verification with a 65,536-byte allowlist and refusal with a 65,537-byte allowlist.

## Scope and qualification

The change uses the existing platform absence check after a failed regular-file open. The registered regression uses a directory at the file path so the failure also occurs for privileged test runners. It covers foreign-key refusal, signer-state reporting and successful own-key verification in that condition. Later read, size and allocation failures and individual seed opens keep their previous behavior.

Executed on Linux using the existing four-CPU, 24 GiB, zero-swap build lane. The two focused groups were `test_dev_proof_signer` and `test_dev_land_remote`. The impact run used the exact parent. Commands and receipts are in [qualification.json](qualification.json). Exact-candidate static review reported no blocker. [Review](independent-review.txt)

The unchanged prerequisite retains publisher request [7079435539](https://github.com/CesareFI/zclassic-node-development/issues/2#issuecomment-7079435539). The four completed discovery trials retain their [published evidence](https://github.com/CesareFI/zclassic-node-development/tree/bf26e391ac930cda98912382fd3994cbb04f6d35/review-artifacts/worldstream-receipt-discovery-20261122).
